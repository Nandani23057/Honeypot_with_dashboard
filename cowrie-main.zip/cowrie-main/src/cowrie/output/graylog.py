# SPDX-FileCopyrightText: 2021 smalinkin <malinkinsa@yandex.ru>
# SPDX-FileCopyrightText: 2022-2026 Michel Oosterhof <michel@oosterhof.net>
#
# SPDX-License-Identifier: BSD-3-Clause

"""
Simple Graylog HTTP Graylog Extended Log Format (GELF) logger.
"""

from __future__ import annotations

import json
import time
from io import BytesIO

from twisted.internet import reactor, ssl
from twisted.logger import Logger
from twisted.web import client, http_headers
from twisted.web.client import FileBodyProducer
from twisted.web.iweb import IPolicyForHTTPS
from zope.interface import implementer

import cowrie.core.output
from cowrie.core.config import CowrieConfig


class Output(cowrie.core.output.Output):
    _log = Logger()

    def start(self) -> None:
        self.url = CowrieConfig.get("output_graylog", "url").encode("utf8")
        contextFactory = WhitelistContextFactory()
        self.agent = client.Agent(reactor, contextFactory)

    def stop(self) -> None:
        pass

    def write(self, event):
        for i in list(event):
            # Remove twisted 15 legacy keys
            if i.startswith("log_"):
                del event[i]

        gelf_message = {
            "version": "1.1",
            "host": event["sensor"],
            "timestamp": time.time(),
            "short_message": json.dumps(event),
            "level": 1,
        }

        self.postentry(gelf_message)

    def postentry(self, entry):
        headers = http_headers.Headers(
            {
                b"Content-Type": [b"application/json"],
            }
        )

        body = FileBodyProducer(BytesIO(json.dumps(entry).encode("utf8")))
        d = self.agent.request(b"POST", self.url, headers, body)
        d.addErrback(self._request_failed)

    def _request_failed(self, failure):
        # Best-effort telemetry: log a failed request (timeout, DNS, reset,
        # ...) rather than leave it as an unhandled Deferred error.
        self._log.info(
            "Graylog request failed: {error}", error=failure.getErrorMessage()
        )


@implementer(IPolicyForHTTPS)
class WhitelistContextFactory:
    def creatorForNetloc(self, hostname, port):
        return ssl.CertificateOptions(verify=False)
