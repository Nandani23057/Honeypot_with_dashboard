# SPDX-FileCopyrightText: 2018-2025 Michel Oosterhof <michel@oosterhof.net>
#
# SPDX-License-Identifier: BSD-3-Clause
from __future__ import annotations

import os
import tempfile
import unittest

from cowrie.shell.protocol import HoneyPotInteractiveProtocol
from cowrie.test.fake_server import FakeAvatar, FakeServer
from cowrie.test.fake_transport import FakeTransport

os.environ["COWRIE_HONEYPOT_DATA_PATH"] = "data"
os.environ["COWRIE_HONEYPOT_DOWNLOAD_PATH"] = tempfile.gettempdir()
os.environ["COWRIE_SHELL_FILESYSTEM"] = "src/cowrie/data/fs.pickle"

PROMPT = b"root@unitTest:~# "


class ShellEchoCommandTests(unittest.TestCase):
    """Test for echo command from cowrie/commands/base.py."""

    proto = HoneyPotInteractiveProtocol(FakeAvatar(FakeServer()))
    tr = FakeTransport("", "31337")

    @classmethod
    def setUpClass(cls) -> None:
        cls.proto.makeConnection(cls.tr)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.proto.connectionLost()

    def setUp(self) -> None:
        self.tr.clear()

    def test_echo_command_001(self) -> None:
        self.proto.lineReceived(b'echo "test"\n')
        self.assertEqual(self.tr.value(), b"test\n" + PROMPT)

    def test_echo_command_002(self) -> None:
        self.proto.lineReceived(b"echo test  test\n")
        self.assertEqual(self.tr.value(), b"test test\n" + PROMPT)

    def test_echo_command_003(self) -> None:
        self.proto.lineReceived(b'echo -n "test  test"\n')
        self.assertEqual(self.tr.value(), b"test  test" + PROMPT)

    def test_echo_command_005(self) -> None:
        self.proto.lineReceived(b"echo test > test5; cat test5")
        self.assertEqual(self.tr.value(), b"test\n" + PROMPT)

    def test_echo_command_006(self) -> None:
        self.proto.lineReceived(b'echo "\\n"\n')
        self.assertEqual(self.tr.value(), b"\\n\n" + PROMPT)

    def test_echo_command_007(self) -> None:
        self.proto.lineReceived(b"echo test >> test7; cat test7")
        self.assertEqual(self.tr.value(), b"test\n" + PROMPT)

    def test_echo_command_008(self) -> None:
        self.proto.lineReceived(b"echo test > test8; echo test >> test8; cat test8")
        self.assertEqual(self.tr.value(), b"test\ntest\n" + PROMPT)

    def test_echo_command_009(self) -> None:
        self.proto.lineReceived(b"echo test | grep test")
        self.assertEqual(self.tr.value(), b"test\n" + PROMPT)

    def test_echo_command_010(self) -> None:
        self.proto.lineReceived(b"echo test | grep test2")
        self.assertEqual(self.tr.value(), PROMPT)

    def test_echo_command_011(self) -> None:
        self.proto.lineReceived(b"echo test > test011; cat test011 | grep test")
        self.assertEqual(self.tr.value(), b"test\n" + PROMPT)

    def test_echo_command_012(self) -> None:
        self.proto.lineReceived(b"echo test > test012; grep test test012")
        self.assertEqual(self.tr.value(), b"test\n" + PROMPT)

    def test_echo_command_013(self) -> None:
        self.proto.lineReceived(b'echo "ls""ls"')
        self.assertEqual(self.tr.value(), b"lsls\n" + PROMPT)

    def test_echo_command_014(self) -> None:
        self.proto.lineReceived(b"echo '\"ls\"'")
        self.assertEqual(self.tr.value(), b'"ls"\n' + PROMPT)

    def test_echo_command_015(self) -> None:
        self.proto.lineReceived(b"echo \"'ls'\"")
        self.assertEqual(self.tr.value(), b"'ls'\n" + PROMPT)

    def test_echo_command_016(self) -> None:
        self.proto.lineReceived(b'echo -e "\x6b\x61\x6d\x69"')
        self.assertEqual(self.tr.value(), b"kami\n" + PROMPT)

    def test_echo_command_017(self) -> None:
        self.proto.lineReceived(b"echo echo test | bash")
        self.assertEqual(self.tr.value(), b"test\n" + PROMPT)

    def test_echo_command_018(self) -> None:
        self.proto.lineReceived(b"echo $(echo test)")
        self.assertEqual(self.tr.value(), b"test\n" + PROMPT)

    def test_echo_command_019(self) -> None:
        self.proto.lineReceived(b"echo $(echo $(echo test))")
        self.assertEqual(self.tr.value(), b"test\n" + PROMPT)

    def test_echo_command_020(self) -> None:
        self.proto.lineReceived(b"echo test_$(echo test)_test")
        self.assertEqual(self.tr.value(), b"test_test_test\n" + PROMPT)

    def test_echo_command_022(self) -> None:
        # A subshell runs in sequence with the surrounding line: the preceding
        # command's output comes first, like bash (`echo b; (echo a)` -> b, a).
        self.proto.lineReceived(b"echo b; (echo a)")
        self.assertEqual(self.tr.value(), b"b\na\n" + PROMPT)

    def test_echo_command_023(self) -> None:
        self.proto.lineReceived(b"echo `echo test`")
        self.assertEqual(self.tr.value(), b"test\n" + PROMPT)

    def test_echo_command_024(self) -> None:
        self.proto.lineReceived(b"echo test_`echo test`_test")
        self.assertEqual(self.tr.value(), b"test_test_test\n" + PROMPT)

    def test_echo_command_026(self) -> None:
        self.proto.lineReceived(b'echo "TEST1: `echo test1`, TEST2: `echo test2`"')
        self.assertEqual(self.tr.value(), b"TEST1: test1, TEST2: test2\n" + PROMPT)

    def test_echo_command_027(self) -> None:
        self.proto.lineReceived(b"echo $LOGNAME")
        self.assertEqual(self.tr.value(), b"root\n" + PROMPT)

    def test_echo_command_028(self) -> None:
        self.proto.lineReceived(b"echo ${LOGNAME}")
        self.assertEqual(self.tr.value(), b"root\n" + PROMPT)

    def test_echo_command_029(self) -> None:
        self.proto.lineReceived(b"echo $(e)")
        self.assertEqual(self.tr.value(), b"-bash: e: command not found\n\n" + PROMPT)

    def test_subshell_parentheses_001(self) -> None:
        """Test basic subshell execution with parentheses - should output directly"""
        self.proto.lineReceived(b"(echo hello)")
        self.assertEqual(self.tr.value(), b"hello\n" + PROMPT)

    def test_subshell_parentheses_003(self) -> None:
        """Test parentheses with multiple commands - should execute all commands"""
        self.proto.lineReceived(b"(echo hello; echo world)")
        self.assertEqual(self.tr.value(), b"hello\nworld\n" + PROMPT)

    def test_subshell_parentheses_004(self) -> None:
        """Test parentheses in middle of command line is syntax error"""
        self.proto.lineReceived(b"echo before (echo middle) after")
        self.assertEqual(
            self.tr.value(),
            b"-bash: syntax error near unexpected token `(echo'\n" + PROMPT,
        )

    def test_subshell_parentheses_005(self) -> None:
        """Test command substitution does substitute output into command line"""
        self.proto.lineReceived(b"echo before $(echo middle) after")
        self.assertEqual(self.tr.value(), b"before middle after\n" + PROMPT)

    def test_subshell_parentheses_006(self) -> None:
        """Test complex subshell with pipes syntax error - regression test"""
        self.proto.lineReceived(b'abc ; uname -a (abc; uname -a) |tr "\\n" "|"')
        # Should be a syntax error due to parentheses after uname -a
        output = self.tr.value()
        self.assertIn(b"-bash: abc: command not found", output)
        self.assertIn(b"syntax error near unexpected token", output)

    def test_subshell_parentheses_008(self) -> None:
        """Test subshell with different command separators"""
        self.proto.lineReceived(b"(echo first && echo second)")
        output = self.tr.value()
        self.assertIn(b"first", output)
        self.assertIn(b"second", output)

    def test_subshell_parentheses_009(self) -> None:
        """`||` short-circuits: the first command succeeds, so the second is
        skipped (like bash)."""
        self.proto.lineReceived(b"(echo first || echo second)")
        self.assertEqual(self.tr.value(), b"first\n" + PROMPT)

    def test_subshell_ordering(self) -> None:
        """A subshell between two commands keeps bash's output order."""
        self.proto.lineReceived(b"echo a; (echo b; echo c); echo d")
        self.assertEqual(self.tr.value(), b"a\nb\nc\nd\n" + PROMPT)

    def test_command_substitution_multiple_commands(self) -> None:
        """Test command substitution with multiple commands"""
        self.proto.lineReceived(b"echo $(echo first; echo second)")
        self.assertEqual(self.tr.value(), b"first second\n" + PROMPT)

    def test_command_substitution_in_middle_multiple(self) -> None:
        """Test command substitution in middle with multiple commands"""
        self.proto.lineReceived(b"echo before $(echo first; echo second) after")
        self.assertEqual(self.tr.value(), b"before first second after\n" + PROMPT)

    def test_command_substitution_space_after_paren(self) -> None:
        """Test command substitution with a space after $( - regression for #40164"""
        self.proto.lineReceived(b"echo $( echo hello)")
        self.assertEqual(self.tr.value(), b"hello\n" + PROMPT)

    def test_command_substitution_nested_subshell(self) -> None:
        """Nested subshell in command substitution must not crash or drop later
        commands - regression for #40164"""
        self.proto.lineReceived(b"x=$( (echo hello) ); echo done")
        output = self.tr.value()
        self.assertNotIn(b"syntax error", output)
        self.assertIn(b"done", output)

    def test_command_substitution_nested_subshell_pipe(self) -> None:
        """Nested subshell piped inside command substitution must not crash or
        drop later commands - regression for #40164"""
        self.proto.lineReceived(b"cpus=$( (echo 4) | head -1 ); echo done")
        output = self.tr.value()
        self.assertNotIn(b"syntax error", output)
        self.assertIn(b"done", output)

    def test_escaped_backslash_in_double_quotes(self) -> None:
        """Inside double quotes \\\\ is one backslash, as in bash."""
        self.proto.lineReceived(b'echo "a\\\\b"\n')
        self.assertEqual(self.tr.value(), b"a\\b\n" + PROMPT)

    def test_escaped_backslash_before_closing_quote(self) -> None:
        self.proto.lineReceived(b'echo "a\\\\\\\\"\n')
        self.assertEqual(self.tr.value(), b"a\\\\\n" + PROMPT)

    def test_lone_backslash_in_double_quotes_is_kept(self) -> None:
        self.proto.lineReceived(b'echo "a\\qb"\n')
        self.assertEqual(self.tr.value(), b"a\\qb\n" + PROMPT)

    def test_command_substitution_captures_bash_c(self) -> None:
        self.proto.lineReceived(b'x=$(bash -c "echo hi"); echo "[$x]"\n')
        self.assertEqual(self.tr.value(), b"[hi]\n" + PROMPT)

    def test_command_substitution_captures_sh_c(self) -> None:
        self.proto.lineReceived(b"x=$(sh -c 'echo hi' 2>&1); echo \"[$x]\"\n")
        self.assertEqual(self.tr.value(), b"[hi]\n" + PROMPT)

    def test_subshell_stderr_duplicated_into_capture(self) -> None:
        self.proto.lineReceived(b'x=$( (xxxxxx) 2>&1 ); echo "[$x]"\n')
        self.assertEqual(
            self.tr.value(), b"[-bash: xxxxxx: command not found]\n" + PROMPT
        )

    def test_subshell_stderr_duplicated_into_pipe(self) -> None:
        # len("-bash: ./xxxxxx: No such file or directory\n") == 43
        self.proto.lineReceived(b"( ./xxxxxx 2>&1 || true ) | wc -c\n")
        self.assertEqual(self.tr.value(), b"43\n" + PROMPT)

    def test_subshell_stderr_to_devnull_hides_not_found(self) -> None:
        self.proto.lineReceived(b"( xxxxxx ) 2>/dev/null; echo rc=$?\n")
        self.assertEqual(self.tr.value(), b"rc=127\n" + PROMPT)

    def test_three_nested_cases_without_final_dsemi(self) -> None:
        self.proto.lineReceived(
            b"case a in N) ;; *) case a in N) ;; *) case a in N) ;; *) "
            b"echo deep; esac; esac; esac\n"
        )
        self.assertEqual(self.tr.value(), b"deep\n" + PROMPT)

    def test_esac_as_an_argument(self) -> None:
        self.proto.lineReceived(b"echo esac; case a in a) echo esac;; esac\n")
        self.assertEqual(self.tr.value(), b"esac\nesac\n" + PROMPT)

    def test_esac_in_command_position_is_a_syntax_error(self) -> None:
        self.proto.lineReceived(b"esac\n")
        self.assertEqual(
            self.tr.value(),
            b"-bash: syntax error near unexpected token `esac'\n" + PROMPT,
        )

    def test_syntax_error_goes_to_stderr(self) -> None:
        self.proto.lineReceived(b"bash -c 'echo (' 2>/dev/null; echo rc=$?\n")
        self.assertEqual(self.tr.value(), b"rc=2\n" + PROMPT)

    def test_stray_closing_keywords_are_syntax_errors(self) -> None:
        for word in (b"fi", b"then", b"done", b"}", b"else", b"do"):
            with self.subTest(word=word):
                self.tr.clear()
                self.proto.lineReceived(word + b"; echo rc=$?\n")
                self.assertEqual(
                    self.tr.value(),
                    b"-bash: syntax error near unexpected token `"
                    + word
                    + b"'\n"
                    + PROMPT,
                )

    def test_closing_keywords_as_arguments(self) -> None:
        self.proto.lineReceived(b"echo fi done }; if true; then echo ok; fi\n")
        self.assertEqual(self.tr.value(), b"fi done }\nok\n" + PROMPT)

    def test_syntax_error_rejects_its_line_after_earlier_lines_ran(self) -> None:
        """bash runs the lines before a syntax error, then reports it and
        runs nothing after it."""
        self.proto.lineReceived(b"echo a\nfi; echo b\necho c\n")
        self.assertEqual(
            self.tr.value(),
            b"a\n-bash: syntax error near unexpected token `fi'\n" + PROMPT,
        )
