# SPDX-FileCopyrightText: 2018 fe7ch
# SPDX-FileCopyrightText: 2018-2026 Michel Oosterhof <michel@oosterhof.net>
#
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

import base64
import binascii
import getopt
import sys

from cowrie.shell.command import HoneyPotCommand
from cowrie.shell.fs import FileNotFound

commands = {}


class Command_base64(HoneyPotCommand):
    """
    author: Ivan Korolev (@fe7ch)
    """

    consumes_stdin = True

    mode: str
    ignore: bool

    def start(self) -> None:
        self.mode = "e"
        self.ignore = False

        try:
            optlist, args = getopt.getopt(
                self.args,
                "diw:",
                ["version", "help", "decode", "ignore-garbage", "wrap="],
            )
        except getopt.GetoptError:
            self.errorWrite("Unrecognized option\n")
            self.exit(1)
            return

        for opt in optlist:
            if opt[0] == "--help":
                self.write(
                    """Usage: base64 [OPTION]... [FILE]
Base64 encode or decode FILE, or standard input, to standard output.

Mandatory arguments to long options are mandatory for short options too.
  -d, --decode          decode data
  -i, --ignore-garbage  when decoding, ignore non-alphabet characters
  -w, --wrap=COLS       wrap encoded lines after COLS character (default 76).
                        Use 0 to disable line wrapping

      --help     display this help and exit
      --version  output version information and exit

With no FILE, or when FILE is -, read standard input.

The data are encoded as described for the base64 alphabet in RFC 3548.
When decoding, the input may contain newlines in addition to the bytes of
the formal base64 alphabet.  Use --ignore-garbage to attempt to recover
from any other non-alphabet bytes in the encoded stream.

Report base64 bugs to bug-coreutils@gnu.org
GNU coreutils home page: <http://www.gnu.org/software/coreutils/>
General help using GNU software: <http://www.gnu.org/gethelp/>
For complete documentation, run: info coreutils 'base64 invocation'
"""
                )
                self.exit()
                return
            elif opt[0] == "--version":
                self.write(
                    """base64 (GNU coreutils) 8.21
Copyright (C) 2013 Free Software Foundation, Inc.
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>.
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.

Written by Simon Josefsson.
"""
                )
                self.exit()
                return
            elif opt[0] == "-d" or opt[0] == "--decode":
                self.mode = "d"

            elif opt[0] == "-i" or opt[0] == "--ignore-garbage":
                self.ignore = True

            elif opt[0] == "-w" or opt[0] == "wrap":
                pass

        if len(args) == 0:
            if self.input_data:
                self.dojob(self.input_data)
            else:
                return
        else:
            if len(args) > 1:
                self.errorWrite(
                    f"""base64: extra operand '{args[0]}'
Try 'base64 --help' for more information.
"""
                )
                self.exit(1)
                return

            pname = self.fs.resolve_path(args[0], self.cwd)
            if not self.fs.isdir(pname):
                try:
                    self.dojob(self.fs.file_contents(pname))
                except FileNotFound:
                    self.errorWrite(f"base64: {args[0]}: No such file or directory\n")
                    self.exit_code = 1
            else:
                self.errorWrite("base64: read error: Is a directory\n")
                self.exit_code = 1

        self.exit()

    def dojob(self, s: bytes) -> None:
        if self.ignore:
            s = b"".join(
                [
                    i.to_bytes(1, sys.byteorder)
                    for i in s
                    if i
                    in b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
                ]
            )

        if self.mode == "e":
            self.writeBytes(base64.b64encode(s))
            self.writeBytes(b"\n")
        else:
            # Like GNU base64 without -i, a byte outside the alphabet (other
            # than a line break) is an error, not something to skip.
            try:
                self.writeBytes(base64.b64decode(s.replace(b"\n", b""), validate=True))
            except binascii.Error:
                self.errorWrite("base64: invalid input\n")
                self.exit_code = 1

    def lineReceived(self, line: str) -> None:
        self.protocol.events.dispatch(
            "cowrie.session.input",
            "INPUT (%(realm)s): %(input)s",
            realm="base64",
            input=line,
        )

        self.dojob(line.encode("utf-8"))

    def eofReceived(self) -> None:
        self.exit()


commands["/usr/bin/base64"] = Command_base64
commands["base64"] = Command_base64
